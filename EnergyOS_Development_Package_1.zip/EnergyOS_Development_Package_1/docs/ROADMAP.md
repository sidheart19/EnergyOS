# Sprint 1
- Authentication
- Dashboard
- Project creation
- Bill upload
